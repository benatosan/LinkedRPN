//Calcs.h
#include "Stack.h"

class Calcs : public Stack{
    public :
    void add();
    void sub();
    void multiply();
    void divide();
    float display();
};