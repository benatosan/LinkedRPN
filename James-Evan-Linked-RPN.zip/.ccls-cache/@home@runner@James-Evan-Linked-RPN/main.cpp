#include <iostream>
#include "Calcs.h"

using namespace std;

void infShow(Calcs calcul1);
int option();

int main() {
    //declaring and initializing variables
  Calcs calcul;
  float newnum;
  bool resume = true;
  bool empty = true;
  char end;
  int choice;

    //while there are no numbers or only 1
  while(empty == true){
      if (calcul.nElements() == 0){
          for (int i = 0; i < 2; i++){
            cout << "2 numbers needed to operate, enter a number: " << endl;
            cin >> newnum;
            calcul.push(newnum); 
            }  
        } else if (calcul.nElements() == 1){
            cout << "2 numbers needed to operate, enter a number: " << endl;
            cin >> newnum;
            calcul.push(newnum);
      } 
      //displays top 2 numbers of the stack
    infShow(calcul);
    empty = false;
        //while user wants to continue, stack is not empty and there is more than 1 num
    while (resume && empty == false){
        choice = option(); //takes in user's choice
        switch (choice){   //switch on the user's choice
            case 1 : cout << "enter number to push : " << endl;
                    cin >> newnum;
                    calcul.push(newnum);
                    break;
            case 2 : calcul.pop();
                    break;
            case 3 : calcul.add();
                    break;
            case 4 : calcul.sub();
                    break;
            case 5 : calcul.multiply();
                    break;
            case 6 : calcul.divide();
                    break;
        }
        infShow(calcul); //displays top 2 nums

        //checks if stack is empty
        if (calcul.nElements() <=1){
            empty = true;
        } else {
            empty = false;
        }

        //finds out if user wants to do another calculation
        cout << "Again? (y/n)" << endl;
        cin >> end;

        switch (end){
            case 'y' : resume = true;
                        break;
            case 'n' : resume = false;
                        empty = false;
                        break;
        }
    }
  }
  
} 

//function prints the options and returns the user's choice
int option(){
    int choice;

    cout << endl << "Enter the number of an option:" << endl << "1. Push another number" << endl << "2. Pop to remove last push" << endl << "3. Add" << endl << "4. Subtract" << endl << "5. Multiply" << endl << "6. Divide" << endl;
    cin >> choice;

    return choice;
}

//function displays top 2 nums without changing stack
void infShow(Calcs calcul1){
    if(calcul1.nElements() >= 2){
        float a = calcul1.display();
        float temp = calcul1.pop();
        float b = calcul1.display();
        calcul1.push(temp);
        cout << endl << "top 2 numbers: " << a << ", " << b << endl;
    } else if (calcul1.nElements() == 1){
        float a = calcul1.display();
        cout << endl << "top 2 numbers: " << a << ", 0" << endl;
    }
    
}