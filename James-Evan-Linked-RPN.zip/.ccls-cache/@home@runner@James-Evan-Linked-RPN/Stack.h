//Stack.h

struct NODE{
        float data;
        NODE *next;
    };

class Stack{
    protected:
    NODE *head;

    public:
    Stack();
    void push(float a);
    float pop();
    float nElements();
};