#include "Stack.h"
#include <iostream>

using namespace std;

Stack::Stack(){
    head = NULL;
}
void Stack::push(float a){
    NODE *newnode = new NODE;
    if (newnode){
        newnode->data = a;
        newnode->next = head;
        head = newnode;   
    }
}
float Stack::pop(){
    float returnValue = head->data;
    NODE *toDelete = head;
    head = toDelete->next;
    delete toDelete;

    return returnValue;
}
float Stack::nElements(){
    int counter = 0;
    for (NODE *node = head; node; node = node->next){
        counter++;
    }
    return counter;
}