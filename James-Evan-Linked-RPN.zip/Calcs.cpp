#include "Calcs.h"

void Calcs::add(){
    float a = pop();
    float b = pop();
    push(a + b);   
}
void Calcs::sub(){
    float a = pop();
    float b = pop();
    push(a - b);
    }
void Calcs::multiply(){
    float a = pop();
    float b = pop();
    push(a * b);
}
void Calcs::divide(){
    float a = pop();
    float b = pop();
    push(a / b);
}
float Calcs::display(){
    float subj = pop();
    push(subj);
    return subj;
}